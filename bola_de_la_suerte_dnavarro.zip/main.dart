import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: LuckyBall(),
    );
  }
}

class LuckyBall extends StatefulWidget {
  @override
  _LuckyBallState createState() => _LuckyBallState();
}

class _LuckyBallState extends State<LuckyBall> {
  int ballNumber = 0;
  int previousBallNumber = -1;

  void changeBall() {
    int randomNumber;
    do {
      randomNumber = Random().nextInt(5) + 1;
    } while (randomNumber == previousBallNumber); // Repite hasta que el número generado sea diferente al anterior

    setState(() {
      previousBallNumber = ballNumber;
      ballNumber = randomNumber;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Bola de la suerte'),
      ),
      body: Center(
        child: GestureDetector(
          onTap: () {
            changeBall();
          },
          child: Image.asset(
            'img/ball$ballNumber.png',
            width: 500,
            height: 500,
          ),
        ),
      ),
    );
  }
}
